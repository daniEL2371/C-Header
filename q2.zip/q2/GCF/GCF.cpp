#include <iostream>
#include "header.h"
using namespace std;


int main() {
	int firstNum, secondNum;
	cout << "Enter the first number: ";
	cin >> firstNum;
	cout << "Enter the second number: ";
	cin >> secondNum;
	cout << "Greatest Common factor is: ";
	cout << calculateGCF(firstNum, secondNum) << endl;
}
int calculateGCF(int firstNum, int secondNum) {
	int divisor = 1;
	
	if(firstNum < secondNum) {
		divisor = firstNum;
	
	} else {
		divisor = secondNum;
	}
	while(true) {
	if(firstNum % divisor == 0) {
		if(secondNum % divisor == 0) {
			return divisor;
		}
	}
	divisor -= 1;
	}

}
