int calculateGCF(int firstNum, int secondNum);
